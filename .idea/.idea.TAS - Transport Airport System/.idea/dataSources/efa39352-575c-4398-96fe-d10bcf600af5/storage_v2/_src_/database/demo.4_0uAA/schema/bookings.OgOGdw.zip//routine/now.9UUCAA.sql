create function now() returns timestamp with time zone
    immutable
    language sql
as
$$SELECT '2017-08-15 18:00:00'::TIMESTAMP AT TIME ZONE 'Europe/Moscow';$$;

comment on function now() is 'Point in time according to which the data are generated';

alter function now() owner to postgres;

